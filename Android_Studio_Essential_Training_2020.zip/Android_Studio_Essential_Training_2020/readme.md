This is my notes for the course Android Studio Essential Training 2020




if installing the Android Studio in a different drive
from the users dir move the ".gradle" file into the folder where the Android Studio is installed


//optional add the "./Android\sdk\platform-tools" to the system path to use the "adb" in cli anywhere

//for updates
	Stable Channel - as the name suggest everything's complete 
	Canary + Dev Channel - preview, bugs, earliest state
	Beta channel - Prepare the release

//the main code is at .app.src.main.java
