import java.io.File
import kotlin.system.measureTimeMillis
import kotlinx.coroutines.*

//ch 7 challenge, count instances of a class
class Bosco{
    companion object{
        var count: Int = 0
        fun show(){
            println("nums of Bosco created: $count")
        }
    }
    init {
        count++
    }
}

fun nop(){ val b = Bosco()}

fun main(){
    //ch 3 challenge, convert the if to when
    val cardPoints = 7_000
    val cardLevel: String = when(cardPoints){
        in 0..999 -> "pearl"
        in 1_000..4_999 -> "silver"
        in 5_000.. 9_999 -> "gold"
        else -> "platinum"
    }
    val plural = if(cardPoints > 1 || cardPoints == 0) "s" else ""
    println("You have $cardPoints point$plural and are at the $cardLevel level.")

    //ch 4 challenge, remove duplicates from a list
    val animals = listOf("apple","biscuit","apple", "cat", "cat", "cat",
        "dog", "elephant", "fox", "goat", "elephant")
    println("result after removing duplicates: ${animals.toSet()}")

    //ch 5 challenge, Create and filter a list from a text file
    val folderFile = "./resources"
    val salesFile = File("$folderFile/sales.txt")
    if (!salesFile.exists()) println("sales.txt file does not exist in the directory")
    else{
        val doubleText = mutableListOf<String>()
        salesFile.forEachLine { if (it.toDoubleOrNull()!= null) doubleText.add(it) }
        println(doubleText)
    }

    //ch 6 Challenge, Pass a function to another function
    fun replicate(func: (Int, String) ->Unit){
        func(3, "Be Cool")
    }
    replicate { count, msg -> for(i in 1..count) println(msg) }

    //ch 7 challenge, count instances of a class
    val b1 = Bosco()
    val b2 = Bosco()
    nop()
    val b3 = Bosco()
    Bosco.show()

    //ch 9 challenge, Read a file in the background
    val whaleFile = File("$folderFile/the_whale.txt")
    if (whaleFile.exists()) {
        val time = measureTimeMillis {
            whaleAsync(whaleFile)
        }
        println(time)
    }

}

//ch 9 challenge, Read a file in the background
fun whaleAsync(whaleFile: File) = runBlocking {
    val lines = async { whaleFile.readLines() }
    lines.await().forEach{ println(it)}
}

