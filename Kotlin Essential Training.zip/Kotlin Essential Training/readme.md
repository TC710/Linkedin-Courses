Notes for the course
Kotlin Essential Training by Troy Miles

and the code is my solution to the course challenge 
the note might have some misspelling but readable. personal notes


How to get Kotlinx to work
web: https://github.com/Kotlin/kotlinx.coroutines
step 1: get the latest version. 7/21/21 recent version: 1.5.1
	- org.jetbrains.kotlinx:kotlinx-coroutines-core:"version#"
step 2: File -> project struct -> Libraries -> "+" -> from Maven
	-type "org.jetbrains.kotlinx:kotlinx-coroutines-core:1.5.1" to search bar
	- after it is selected click apply and ok
	- can also download to the lib and check the source
step 3: click on "build.gradle.kts" file and  
	add "implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.5.1")" to dependencies
step 4: File -> invalidate Caches -> invalidate and restart


kotlinlang.org/docs/reference
play.kotlinlang.org/koans
blog.jetbrains.com/kotlin